// Import the modules
const express = require("express");
const mongoose = require("mongoose");
const cors = require('cors');
const Employee = require('./models/employees'); 

// Create express app
const server = express();

// Environment variables
require("dotenv").config();

// Define the port
const PORT = process.env.PORT || 5000;

// Define CORS options
const corsOptions = {
  origin: 'http://localhost:3000',
  optionsSuccessStatus: 200
};

// Middleware for JSON and CORS
server.use(express.json());
server.use(cors(corsOptions));

// Connect to MongoDB
const DB_URL = process.env.DB_URL || "mongodb://localhost:27017/employees";
mongoose.connect(DB_URL, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("Connected to the database");
  })
  .catch((error) => {
    console.log("Error connecting to the database: ", error);
  });

// API Routes

// Create Operation
server.post('/api/employees', async (req, res) => {
  try {
    const newEmployee = new Employee(req.body);
    await newEmployee.save();
    res.status(201).json(newEmployee);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Read Operation
server.get('/api/employees', async (req, res) => {
  try {
    const employees = await Employee.find();
    res.json(employees);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update Operation
server.put('/api/employees/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const updatedEmployee = req.body;
    const result = await Employee.findByIdAndUpdate(id, updatedEmployee, { new: true });
    if (!result) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json(result);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete Operation
server.delete('/api/employees/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const result = await Employee.findByIdAndDelete(id);
    if (!result) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json({ message: "Employee deleted successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Start the server
server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
