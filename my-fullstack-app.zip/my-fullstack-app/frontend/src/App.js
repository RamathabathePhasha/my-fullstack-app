import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './Components/Home';
import Employees from './Components/Employees';
import Department from './Components/Department';
import './App.css';

function App() {
  return (
    <Router>
      <div>
        <header>
          <h1>Employee Directory</h1>
        </header>
        <nav>
          <ul className="nav justify-content-center">
            <li className="nav-item">
              <Link className="nav-link" to="/">Home</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/employees">All Employees</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/department/Engineering">Engineering</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/department/Marketing">Marketing</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/department/Finance">Finance</Link>
            </li>
          </ul>
        </nav>
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/department/:departmentName" element={<Department />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
