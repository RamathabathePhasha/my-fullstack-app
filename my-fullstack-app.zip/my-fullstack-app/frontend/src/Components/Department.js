import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './Department.css';

function Department() {
  const { departmentName } = useParams();
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/employees')
      .then(response => {
        const filteredEmployees = response.data.filter(employee => employee.department.toLowerCase() === departmentName.toLowerCase());
        setEmployees(filteredEmployees);
      })
      .catch(error => {
        console.log('There was an error fetching the data!', error);
      });
  }, [departmentName]);

  return (
    <div className="container">
      <h2>Employees in {departmentName} Department</h2>
      <table className="table table-hover">
        <thead>
          <tr>
            <th>Name</th>
            <th>Surname</th>
            <th>Gender</th>
            <th>Department</th>
            <th>Salary</th>
          </tr>
        </thead>
        <tbody>
          {employees.map(employee => (
            <tr key={employee.id}>
              <td>{employee.name}</td>
              <td>{employee.surname}</td>
              <td>{employee.gender}</td>
              <td>{employee.department}</td>
              <td>{employee.salary}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Department;
